import java.lang.Integer;

public class Main {

    public static void main(String[] args) {
        Toolbox toolbox = new Toolbox();
        Integer numberToGuess = toolbox.getRandomInteger(10);
        Integer guessedNumber = toolbox.readIntegerFromCmd();
        if(guessedNumber == numberToGuess){
            System.out.println("You win");
        }
        else{
            System.out.println("Try again");
        }
    }
}
